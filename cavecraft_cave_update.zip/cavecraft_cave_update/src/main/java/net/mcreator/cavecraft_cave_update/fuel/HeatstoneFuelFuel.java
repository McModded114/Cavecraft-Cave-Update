
package net.mcreator.cavecraft_cave_update.fuel;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.item.ItemStack;

import net.mcreator.cavecraft_cave_update.block.HeatstoneBlock;
import net.mcreator.cavecraft_cave_update.CavecraftCaveUpdateModElements;

@CavecraftCaveUpdateModElements.ModElement.Tag
public class HeatstoneFuelFuel extends CavecraftCaveUpdateModElements.ModElement {
	public HeatstoneFuelFuel(CavecraftCaveUpdateModElements instance) {
		super(instance, 64);
		MinecraftForge.EVENT_BUS.register(this);
	}

	@SubscribeEvent
	public void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		if (event.getItemStack().getItem() == new ItemStack(HeatstoneBlock.block, (int) (1)).getItem())
			event.setBurnTime(1264);
	}
}
