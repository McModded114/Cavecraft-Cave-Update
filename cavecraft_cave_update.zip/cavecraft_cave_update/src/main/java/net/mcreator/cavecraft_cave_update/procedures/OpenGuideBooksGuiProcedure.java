package net.mcreator.cavecraft_cave_update.procedures;

import net.mcreator.cavecraft_cave_update.CavecraftCaveUpdateModElements;

@CavecraftCaveUpdateModElements.ModElement.Tag
public class OpenGuideBooksGuiProcedure extends CavecraftCaveUpdateModElements.ModElement {
	public OpenGuideBooksGuiProcedure(CavecraftCaveUpdateModElements instance) {
		super(instance, 100);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
	}
}
