package net.mcreator.cavecraft_cave_update.procedures;

import net.minecraft.entity.Entity;

import net.mcreator.cavecraft_cave_update.CavecraftCaveUpdateModElements;

@CavecraftCaveUpdateModElements.ModElement.Tag
public class HeatstoneHeatProcedure extends CavecraftCaveUpdateModElements.ModElement {
	public HeatstoneHeatProcedure(CavecraftCaveUpdateModElements instance) {
		super(instance, 26);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure HeatstoneHeat!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		entity.setFire((int) 3);
	}
}
