package net.mcreator.cavecraft_cave_update.procedures;

import net.mcreator.cavecraft_cave_update.CavecraftCaveUpdateModElements;

@CavecraftCaveUpdateModElements.ModElement.Tag
public class SetPlayerVariablesFromEntityProcedure extends CavecraftCaveUpdateModElements.ModElement {
	public SetPlayerVariablesFromEntityProcedure(CavecraftCaveUpdateModElements instance) {
		super(instance, 16);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
	}
}
