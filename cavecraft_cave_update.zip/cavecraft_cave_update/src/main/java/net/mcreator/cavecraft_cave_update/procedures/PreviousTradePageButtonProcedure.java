package net.mcreator.cavecraft_cave_update.procedures;

import net.minecraft.entity.Entity;

import net.mcreator.cavecraft_cave_update.CavecraftCaveUpdateModElements;

@CavecraftCaveUpdateModElements.ModElement.Tag
public class PreviousTradePageButtonProcedure extends CavecraftCaveUpdateModElements.ModElement {
	public PreviousTradePageButtonProcedure(CavecraftCaveUpdateModElements instance) {
		super(instance, 19);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure PreviousTradePageButton!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (((entity.getPersistentData().getDouble("playerTradePage")) == 3)) {
			entity.getPersistentData().putDouble("playerTradePage", 2);
		} else if (((entity.getPersistentData().getDouble("playerTradePage")) == 2)) {
			entity.getPersistentData().putDouble("playerTradePage", 1);
		}
	}
}
