package net.mcreator.cavecraft_cave_update.procedures;

import net.mcreator.cavecraft_cave_update.CavecraftCaveUpdateModElements;

@CavecraftCaveUpdateModElements.ModElement.Tag
public class CavemanTradeVariablesProcedure extends CavecraftCaveUpdateModElements.ModElement {
	public CavemanTradeVariablesProcedure(CavecraftCaveUpdateModElements instance) {
		super(instance, 76);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
	}
}
