package net.mcreator.cavecraftcaveupdate.procedures;

import net.minecraft.entity.Entity;

import net.mcreator.cavecraftcaveupdate.CavecraftCaveUpdateModElements;

import java.util.Map;

@CavecraftCaveUpdateModElements.ModElement.Tag
public class FirstPageProcedure extends CavecraftCaveUpdateModElements.ModElement {
	public FirstPageProcedure(CavecraftCaveUpdateModElements instance) {
		super(instance, 2);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure FirstPage!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (((entity.getPersistentData().getDouble("playerTradePage")) == 3)) {
			entity.getPersistentData().putDouble("playerTradePage", 2);
		} else if (((entity.getPersistentData().getDouble("playerTradePage")) == 2)) {
			entity.getPersistentData().putDouble("playerTradePage", 1);
		}
	}
}
