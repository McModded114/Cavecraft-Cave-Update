
package net.mcreator.cavecraftcaveupdate.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.cavecraftcaveupdate.block.LimestoneStalagmiteBlock;
import net.mcreator.cavecraftcaveupdate.CavecraftCaveUpdateModElements;

@CavecraftCaveUpdateModElements.ModElement.Tag
public class StalagmitesItemGroup extends CavecraftCaveUpdateModElements.ModElement {
	public StalagmitesItemGroup(CavecraftCaveUpdateModElements instance) {
		super(instance, 109);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabstalagmites") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(LimestoneStalagmiteBlock.block, (int) (1));
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundImageName("item_search.png");
	}
	public static ItemGroup tab;
}
