
package net.mcreator.cavecraftcaveupdate.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.cavecraftcaveupdate.block.LimestoneStalactiteBlock;
import net.mcreator.cavecraftcaveupdate.CavecraftCaveUpdateModElements;

@CavecraftCaveUpdateModElements.ModElement.Tag
public class StalactitesItemGroup extends CavecraftCaveUpdateModElements.ModElement {
	public StalactitesItemGroup(CavecraftCaveUpdateModElements instance) {
		super(instance, 108);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabstalactites") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(LimestoneStalactiteBlock.block, (int) (1));
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundImageName("item_search.png");
	}
	public static ItemGroup tab;
}
