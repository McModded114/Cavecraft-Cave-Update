package net.mcreator.cavecraftcaveupdate.procedures;

import net.minecraft.entity.Entity;

import net.mcreator.cavecraftcaveupdate.CavecraftCaveUpdateModElements;

import java.util.Map;

@CavecraftCaveUpdateModElements.ModElement.Tag
public class NextPageProcedure extends CavecraftCaveUpdateModElements.ModElement {
	public NextPageProcedure(CavecraftCaveUpdateModElements instance) {
		super(instance, 1);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure NextPage!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (((entity.getPersistentData().getDouble("playerTradePage")) == 1)) {
			entity.getPersistentData().putDouble("playerTradePage", 2);
		} else if (((entity.getPersistentData().getDouble("playerTradePage")) == 2)) {
			entity.getPersistentData().putDouble("playerTradePage", 3);
		}
	}
}
